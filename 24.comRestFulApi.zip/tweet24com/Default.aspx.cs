﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace tweet24com
{
    public partial class _Default : Page
    {
        protected void getTimeLineButton_Click(object sender, EventArgs e)
        {
            // check if a value for the screen name was entered.
            if (string.IsNullOrEmpty(userScreenNameTextBox.Text))
            {
                userScreenNameMessageLabel.Text = "Username has to be entered.";
                return;
            }

            if (string.IsNullOrEmpty(displayCountTextBox.Text))
            {
                displayCountMessageLabel.Text = "Number of Tweets to display has to be entered.";
                return;
            }

            userScreenNameMessageLabel.Text = "";
            displayCountMessageLabel.Text = "";

            ScriptManager.RegisterStartupScript(this, this.GetType(), "getRestResponse", "javascript:callRestAPI();", true);
        }
    }
}