﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(tweet24com.Startup))]
namespace tweet24com
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
