﻿using System.Web.UI;

namespace tweet24com.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}