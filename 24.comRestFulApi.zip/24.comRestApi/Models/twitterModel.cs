﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace _24.comRestApi.Models
{
    public class twitterModel : IDisposable
    {
        #region Private Properties
        private object tokenValue;
        private object tokenSecret;
        private object accessValue;
        private object accessSecret;
        private object timelineURL;
        #endregion

        #region Private Methods
        #endregion

        #region Public Methods
        public object getTokenValue()
        {
            tokenValue = null;
            try
            {
                tokenValue = System.Configuration.ConfigurationManager.AppSettings.Get("consumerKey");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return tokenValue;

        }

        public object getTokenSecret()
        {
            tokenSecret = null;
            try
            {
                tokenSecret = System.Configuration.ConfigurationManager.AppSettings.Get("consumerSecret");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return tokenSecret;

        }

        public object getAccessValue()
        {
            accessValue = null;
            try
            {
                accessValue = System.Configuration.ConfigurationManager.AppSettings.Get("accessToken");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return accessValue;

        }

        public object getAccessSecret()
        {
            accessSecret = null;
            try
            {
                accessSecret = System.Configuration.ConfigurationManager.AppSettings.Get("accessSecret");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return accessSecret;
        }

        public object getTimelineURL()
        {
            timelineURL = null;
            try
            {
                timelineURL = System.Configuration.ConfigurationManager.AppSettings.Get("timelineURL");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return timelineURL;

        }
        
        public void Dispose()
        {
            if (timelineURL != null)
                timelineURL = null;
            if (accessSecret != null)
                accessSecret = null;
            if (accessValue != null)
                accessValue = null;
            if (tokenValue != null)
                tokenValue = null;
            if (tokenSecret != null)
                tokenSecret = null;
        }
        #endregion
    }
}