﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Web.Script.Serialization;

namespace _24.comRestApi.Controllers
{
    [EnableCors("*", "*", "*")]
    public class twitterController : ApiController
    {
        #region private properties
        private string tokenValue;
        private string tokenSecret;
        private string accessValue;
        private string accessSecret;
        private string timelineURL;
        #endregion

        #region private methods
        private void getTokens()
        {
            try
            {
                using (Models.twitterModel model = new Models.twitterModel())
                {
                    tokenValue = model.getTokenValue().ToString();
                    tokenSecret = model.getTokenSecret().ToString();
                    accessValue = model.getAccessValue().ToString();
                    accessSecret = model.getAccessSecret().ToString();
                    timelineURL = model.getTimelineURL().ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        private twitAuthenticateResponse getAuthorizationResponse()
        {
            // You need to set your own keys and screen name
            var oAuthConsumerKey = tokenValue;
            var oAuthConsumerSecret = tokenSecret;
            var oAuthUrl = "https://api.twitter.com/oauth2/token";
            
            // Do the Authenticate
            var authHeaderFormat = "Basic {0}";

            var authHeader = string.Format(authHeaderFormat,
                Convert.ToBase64String(Encoding.UTF8.GetBytes(Uri.EscapeDataString(oAuthConsumerKey) + ":" +
                Uri.EscapeDataString((oAuthConsumerSecret)))
            ));

            var postBody = "grant_type=client_credentials";

            HttpWebRequest authRequest = (HttpWebRequest)WebRequest.Create(oAuthUrl);


            authRequest.Headers.Add("Authorization", authHeader);
            authRequest.Method = "POST";
            authRequest.ContentType = "application/x-www-form-urlencoded;charset=UTF-8";
            authRequest.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;

            using (Stream stream = authRequest.GetRequestStream())
            {
                byte[] content = ASCIIEncoding.ASCII.GetBytes(postBody);
                stream.Write(content, 0, content.Length);
            }

            authRequest.Headers.Add("Accept-Encoding", "gzip");

            WebResponse authResponse = authRequest.GetResponse();
            // deserialize into an object
            twitAuthenticateResponse twitAuthResponse;
            using (authResponse)
            {
                using (var reader = new StreamReader(authResponse.GetResponseStream()))
                {
                    JavaScriptSerializer js = new JavaScriptSerializer();
                    var objectText = reader.ReadToEnd();
                    twitAuthResponse = JsonConvert.DeserializeObject<twitAuthenticateResponse>(objectText);
                }
            }

            return twitAuthResponse;
        }
        #endregion

        #region public http methods
        [Route("twitter/{twitterHandle}/{tweetCount}")]
        [HttpGet]
        public object Get(string twitterHandle, int tweetCount)
        {
            getTokens();

            var authResponse = getAuthorizationResponse();

            // Retrieve the timeline
            var url = string.Format(timelineURL, twitterHandle, tweetCount);
            HttpWebRequest timeLineRequest = (HttpWebRequest)WebRequest.Create(url);
            var timelineHeaderFormat = "{0} {1}";
            timeLineRequest.Headers.Add("Authorization", string.Format(timelineHeaderFormat, authResponse.token_type, authResponse.access_token));
            timeLineRequest.Method = "Get";
            WebResponse timeLineResponse = timeLineRequest.GetResponse();
            var timeLineJson = string.Empty;
            using (timeLineResponse)
            {
                using (var reader = new StreamReader(timeLineResponse.GetResponseStream()))
                {
                    timeLineJson = reader.ReadToEnd();
                }
            }

            return timeLineJson;
        }

        [HttpGet]
        public object Get(string twitterHandle)
        {
            getTokens();

            var authResponse = getAuthorizationResponse();

            //Retrieve the timeline
           var url = string.Format(timelineURL, twitterHandle, 1);
            HttpWebRequest timeLineRequest = (HttpWebRequest)WebRequest.Create(url);
            var timelineHeaderFormat = "{0} {1}";
            timeLineRequest.Headers.Add("Authorization", string.Format(timelineHeaderFormat, authResponse.token_type, authResponse.access_token));
            timeLineRequest.Method = "Get";
            WebResponse timeLineResponse = timeLineRequest.GetResponse();
            var timeLineJson = string.Empty;
            using (timeLineResponse)
            {
                using (var reader = new StreamReader(timeLineResponse.GetResponseStream()))
                {
                    timeLineJson = reader.ReadToEnd();
                }
            }

            return timeLineJson;
        }
        #endregion
    }
    public class twitAuthenticateResponse
    {
        public string token_type { get; set; }
        public string access_token { get; set; }
    }
}
